package com.rakuten.training.spring;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestProduct {

  @Test
  void test() {
    fail("Not yet implemented");
  }
}
